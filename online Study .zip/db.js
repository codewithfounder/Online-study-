// const dbUrl = "mongodb+srv://virendra1622:CxPnNNWGPfxlsZKs@cluster0.etcwhoq.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";

const mongoose = require("mongoose");

const URL =
  "mongodb+srv://virendra1622:CxPnNNWGPfxlsZKs@cluster0.etcwhoq.mongodb.net/mearn_admin?retryWrites=true&w=majority";
// mongoose.connect(URL);

const connectDb = async () => {
  try {
    await mongoose.connect(URL);
    console.log("connected to db");
  } catch (err) {
    console.log("database connection failed");
    process.exit(0);
  }
};

module.exports = connectDb;